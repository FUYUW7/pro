// pages/comment/comment.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    zzc: 1,//遮罩层
    input_foucs:false,//获取焦点
    input:1,//文本框
    commen_info:{},//回复内容
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //  console.log(options)
     var id=options.id;
     var that=this;
     wx.request({
       url: 'http://60.205.230.52/pro/yii-basic-app-2.0.12/basic/web/index.php?r=address/hf&id='+id,
       dataType:'json',
       success:function(e){
        //  console.log(e.data);
         that.setData({commen:e.data});
       }
     })
  },
  //回复
  hf:function(){
    this.setData({ zzc: 0, input_foucs:true,input:0});
  },
  //失焦获取值
  blur:function(e){
    // console.log(e.detail.value);
    this.setData({commen_info:e.detail.value});
  },
  //发送回复内容
  fs:function(){
    var com=this.data.commen_info;
    console.log(com);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})