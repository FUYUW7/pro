// pages/address/address.js
var webroot ="http://60.205.230.52/pro/yii-basic-app-2.0.12/basic/web/";
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    webroot:webroot,  //路径
    dzcg_flag:1,    //点赞成功
    zzc_flag:1,   //遮罩层
    input_flag:1,    //输入框
    input_focus:false,//获取焦点
    commen_val:'',//评论内容
    commen_info:{},//评论入库
    bwdz_flag:1,//帮我点赞
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var openid ="ozbqK5dalaBhizIUoKBlZPut4CbU";
    var that=this;
      wx.request({
        url: 'http://60.205.230.52/pro/yii-basic-app-2.0.12/basic/web/index.php?r=address/index&openid='+openid,
        method:'GET',
        dataType:'json',
        success:function(res){
          // console.log(res);
         that.setData({datainfo:res.data});
        //  console.log(that.data.datainfo);
         setInterval(that.prizeendtime,1000);
        }
      })
  },

  //回复
  hf:function(e){
    // console.log(e);
    var id = e.currentTarget.id;
    // console.log(id)
    wx.navigateTo({
      url: '/pages/hf/hf?id='+id,
    })
  },

  //点赞
  dz:function(e){
    // console.log(e);
    var that=this;
    var id = e.currentTarget.id;
    // console.log(id);
    var item = e.currentTarget.dataset.item;
    // console.log(item);
    var openid=app.globalData.openid;
    // console.log(openid);
    var pra=this.data.datainfo.commen[item].pra;
    pra++;
    if(openid){
      wx.request({
        url: 'http://60.205.230.52/pro/yii-basic-app-2.0.12/basic/web/index.php?r=address/pra&id=' + id + '&openid=' + openid,
        dataType: 'json',
        success: function (e) {
          // console.log(e);
           if(e.data=='ok'){
            that.data.datainfo.commen[item].pra=pra;
            that.data.datainfo.commen[item].zg='zg-img';
            that.setData({'datainfo.commen':that.data.datainfo.commen});
          }
          if (e.data == 'no'){
         
          }
        }
      })
    }
  },

  //活动剩余时间
  prizeendtime:function(){
    var _time = this.data.datainfo.prize._time;
    _time--;
    var day=parseInt(_time/(60*60*24));
    var hours=parseInt((_time % (60*60*24)) / (60*60));
    var minutes=parseInt((_time % (60*60)) / 60);
    var secounds=parseInt(_time % 60);
    // console.log(secounds);
    var endtime=day+'天'+hours+'时'+minutes+'分'+secounds+'秒';
    // console.log(endtime);
    this.setData({'datainfo.prize._time':_time,end:endtime});
  },
  //赞
  nb:function(){
    var that=this;
    var id=this.data.datainfo.prize.id;
    // console.log(this.data.datainfo.prize.id);
    we:wx.request({
      url: 'http://60.205.230.52/pro/yii-basic-app-2.0.12/basic/web/index.php?r=address/do&type=nb&id='+id,
      method: 'GET',
      dataType: 'json',
      success: function(res) {
        // console.log(res);
       that.setData({'datainfo.prize':res.data})
      }
    })
  },
//踩
  lj: function () {
    var that = this;
    var id = this.data.datainfo.prize.id;
    // console.log(this.data.datainfo.prize.id);
    we: wx.request({
      url: 'http://60.205.230.52/pro/yii-basic-app-2.0.12/basic/web/index.php?r=address/do&type=lj&id=' + id,
      method: 'GET',
      dataType: 'json',
      success: function (res) {
        // console.log(res);
        that.setData({ 'datainfo.prize': res.data })
      }
    })
  },
  //活动规则
  prize:function(){
    wx.navigateTo({
      url: '/pages/prize/prize',
    })
  },
  //参与讨论
  cytl:function(){
    this.setData({zzc_flag:0,input_flag:0,input_focus:true});
  },
  //发送评论
  sendcommen:function(){
    //获取用户id
    var uid=app.globalData.openid;
    if(uid){
    //获取评论内容，将评论内容添加到数据
    var con=this.data.commen_val;
    // console.log(con);
    var arr={
      com_user:uid,
      prize_id:this.data.datainfo.prize.prize_id,
      commen: this.data.commen_val
    };
    var that = this;
    wx.request({
      url: 'http://60.205.230.52/pro/yii-basic-app-2.0.12/basic/web/index.php?r=address/addcom',
      data:arr,
      dataType:'json',
      success:function(e){
       if(e.data=='ok'){
          that.data.commen_info.commen = that.data.commen_val,
            that.data.commen_info.z=0,
           that.setData({ bwdz_flag: 0, commen_info: that.data.commen_info})
       }
      }
    })
    
    this.setData({ zzc_flag: 1, input_flag: 1, input_focus: false });
    }
  },
  //失去焦点事件
  commen_content:function(e){
    // console.log(e)
    this.setData({commen_val:e.detail.value});
  },

  //获取用户信息
  getuser:function(e){
    // console.log(e)
    this.setData({ ucover: e.detail.userInfo.avatarUrl});
    this.setData({ uname:e.detail.userInfo.nickName});
    wx.checkSession({
      success:function(res){
        // console.log(res);
      },
      fail:function(res){
        // console.log(res);
        //登录
        wx.login({
          success:function(ress){
            // console.log(ress.code);
            wx.request({
              url: 'https://api.weixin.qq.com/sns/jscode2session?appid=wx39d02e75b891bac0&secret=2942d8d776d5dabca45c482d7a5cb524&js_code='+ress.code+'&grant_type=authorization_code',
              dataType:'json',
              success:function(resss){
                //获取信息
                var arr = {
                           openid:resss.data.openid,
                           name: e.detail.userInfo.nickName,
                           cover:e.detail.userInfo.avatarUrl
                            }; 
                // console.log(arr);
                //入库
                wx.request({
                  url: 'http://60.205.230.52/pro/yii-basic-app-2.0.12/basic/web/index.php?r=address/adduser',
                  data:arr,
                  method:'get',
                  dataType:'json',
                  success:function(e){
                    if(e.data=='ok'){
                      app.globalData.openid = resss.data.openid;
                    }
                  }
                })
              }
            })
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})